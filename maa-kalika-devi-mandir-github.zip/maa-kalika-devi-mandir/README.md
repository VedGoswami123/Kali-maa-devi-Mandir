# Maa Kalika Devi Mandir — website

The website for the jeernoddhar of Maa Kalika Devi Mandir, Gurh, Rewa. Visitors choose English or Hindi, see each stage of the work with photos from the site, and can contribute through Razorpay. Every contributor is added to the Wall of Devotion.

## Publish it (GitHub + Vercel)

### 1. Put the code on GitHub
1. Sign in at https://github.com and click **New repository**.
2. Name it `maa-kalika-devi-mandir`, choose **Private** or **Public**, and click **Create repository**.
3. On the next page click **uploading an existing file**.
4. Open this folder on your computer, select **everything inside it** (including the `api` and `assets` folders), and drag it into the page.
5. Click **Commit changes**.

> The `.gitignore` file starts with a dot, so your Mac may hide it. That's fine; the site works without it.

### 2. Deploy on Vercel
1. Sign in at https://vercel.com with your GitHub account.
2. Click **Add New → Project**, pick `maa-kalika-devi-mandir`, and click **Deploy**. Leave every setting as it is.
3. After about a minute you get a link like `maa-kalika-devi-mandir.vercel.app`. The site is live.

At this point the site works fully except payments. The contribute button shows a polite "payments are being set up" message.

### 3. Add the database for the Wall of Devotion
1. In your Vercel project, open **Storage** → **Create Database** → **Upstash for Redis** (free plan) → **Continue**.
2. Connect it to this project. Vercel adds the connection details for you.

### 4. Turn on Razorpay
1. In the Razorpay Dashboard go to **Account & Settings → API Keys** and generate a key. Start in **Test Mode**.
2. In Vercel open **Settings → Environment Variables** and add:
   - `RAZORPAY_KEY_ID` — the key id (starts with `rzp_test_` or `rzp_live_`)
   - `RAZORPAY_KEY_SECRET` — the key secret
3. Open **Deployments**, click the three dots on the latest one and choose **Redeploy**.
4. Make a test contribution (Razorpay test UPI: `success@razorpay`). Your name should appear on the Wall of Devotion.
5. When it works, generate **Live Mode** keys in Razorpay, replace both values in Vercel, and redeploy.

The key secret only ever lives in Vercel's settings. Never put it in any file in this repository.

### 5. Your own domain (optional)
In Vercel open **Settings → Domains**, add your domain, and follow the instructions shown.

## Making changes later

Edit a file on GitHub (click it, then the pencil icon) and commit. Vercel republishes the site automatically within a minute.

| What | Where |
|---|---|
| Mandir name, address, contact, goal (₹25 lakh) | `config.js` |
| Stage order, stage photos, stage costs | `stages` in `config.js` |
| All English & Hindi wording | `i18n.js` |
| Photos | `assets/real/` — replace a file with one of the same name |
| Lalji Goswami's portrait | `assets/lalji.jpg` and `assets/lalji-face.jpg` |
| Video posters | `assets/posters/1.jpg` … `6.jpg` |
| Videos | upload each to YouTube (unlisted is fine) and paste the link into `youtube: ""` in `config.js` |

## How it fits together

- `index.html`, `styles.css`, `app.js`, `config.js`, `i18n.js`, `assets/` — the website.
- `api/donors.js` — returns the Wall of Devotion.
- `api/order.js` — creates a Razorpay order.
- `api/verify.js` — checks each payment with Razorpay before adding the name to the wall, so nobody can add themselves without paying. The amount always comes from Razorpay, not from the browser.
- Contributors' email and phone are stored for receipts but are never shown on the website.
