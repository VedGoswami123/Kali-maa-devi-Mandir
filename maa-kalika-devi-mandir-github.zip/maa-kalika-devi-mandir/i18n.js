window.I18N = {
  en: {
    gate_name_kicker: "Welcome",
    gate_name_title: "What may we call you?",
    gate_name_ph: "Your name",
    gate_continue: "Continue",
    gate_skip: "Enter as a guest",
    gate_pranam: "Pranam",
    gate_guest: "dear devotee",
    gate_line: "Thank you for coming. Let us show you what is being built.",

    nav_journey: "The Journey",
    nav_film: "Films",
    nav_wall: "Wall of Devotion",
    nav_about: "The Sankalp",
    nav_give: "Contribute",

    hero_kicker: "Pranam, {name}",
    hero_title: "A temple, raised<br>stone by stone,<br><em>by many hands.</em>",
    hero_sub: "We are rebuilding Maa Kali's mandir in our village. The old walls were giving way, so in August we took them down to build a stronger mandir in the same place. Every contribution, and every name, is part of it.",
    hero_cta: "Offer your contribution",
    hero_more: "Walk through the journey",
    hero_raised: "raised of",
    hero_scroll: "Scroll",

    intro: "A mandir is not built by one person. It is built by the masons who tie the steel by hand, by the neighbours who carry sand on their heads, by the stranger who reads this page and decides to help. This is the story of that building, told honestly, stage by stage.",

    journey_kicker: "The Journey",
    journey_title: "From the old walls to the new kalash.",
    journey_sub: "Every photo here is a frame from our own videos of the site.",
    stage: "Stage",
    budget: "Needs",
    when: "When",
    status_done: "Completed",
    status_now: "In progress",
    status_next: "Upcoming",
    status_maa: "Jai Mata Di",
    stage_give: "Contribute to this stage",
    stage_watch: "Watch the video",

    stages: {
      maa: {
        title: "Maa Kali",
        date: "",
        body: "Everything here begins with Maa. Her murti has blessed the village from the old mandir for many years. While the new mandir is built she sits in a small temporary mandir beside the site, and her puja and shringar continue.",
        items: ["Maa Kalika Devi", "Temporary mandir beside the site", "Puja and shringar continue"]
      },
      brick: {
        title: "Jeernoddhar Puja",
        date: "2 July 2026",
        body: "The jeernoddhar of the mandir began with a puja on the bricks, with roli, rice and flowers, at the shubh muhurat of 9 in the morning. All the villagers and Maa's devotees were invited.",
        items: ["Puja on the bricks", "Shubh muhurat, 9 am", "All villagers and devotees invited"]
      },
      old: {
        title: "The Old Mandir",
        date: "27 June – 2 July 2026",
        body: "This is how Maa's mandir looked before we began. The plaster was coming away in large pieces and damp had got into the walls. We filmed it carefully, so it would always be remembered.",
        items: ["Plaster falling from the walls", "Damp in the old brickwork", "Maa's murti in the old shrine"]
      },
      down: {
        title: "Taking It Down",
        date: "2 – 20 August 2026",
        body: "Over almost three weeks the roof and walls were broken down. Then the outline of the new mandir was marked on the bare ground with chuna.",
        items: ["Roof and walls broken down", "Debris cleared from the plot", "New layout marked in chuna (lime)"]
      },
      ground: {
        title: "Digging & Materials",
        body: "Pits were dug for the foundation. Sand was sieved on site, and trolleys of gitti and bricks arrived for the concrete work.",
        date: "13 – 17 September 2026",
        items: ["Foundation pits dug", "Sand sieved on site", "Gitti (stone chips) and bricks delivered"]
      },
      columns: {
        title: "Steel & Columns",
        date: "From 18 September 2026",
        body: "Steel cages for the columns are tied and set into the pits, and the first concrete footings have been cast. The curved steel follows the shape of the new mandir's base.",
        items: ["Steel for the columns", "Cement and concrete", "Wages for the masons"]
      },
      puja: {
        title: "Maa's Puja Did Not Stop",
        date: "29 September – 11 October 2026",
        body: "While the work goes on, Maa sits in a small temporary mandir beside the site, and her puja and shringar continue.",
        items: ["Temporary mandir beside the site", "Puja continues", "Maa's shringar"]
      },
      walls: {
        title: "Walls & Roof",
        body: "Once the columns stand, the walls of the garbhagriha and the front are built up and the roof slab is cast over them.",
        items: ["Bricks and cement", "Steel for the roof slab", "Shuttering and labour"]
      },
      shikhar: {
        title: "The Shikhar",
        body: "Above the garbhagriha the shikhar rises, as in the design drawing for the new mandir: tier above tier, finished in colour.",
        items: ["Shikhar structure", "Scaffolding", "Decorative work and paint"]
      },
      pratishtha: {
        title: "Kalash & Pran Pratishtha",
        body: "Plaster, flooring and paint come last. Then the kalash is set on the shikhar, Maa is seated in her new garbhagriha, and life is invoked through pran pratishtha.",
        items: ["Plaster, flooring and paint", "Kalash and dhvaja", "Murti sthapana and pran pratishtha"]
      }
    },

    film_kicker: "From the site",
    film_title: "See it with your own eyes.",
    film_soon: "This video will be added soon.",

    goal_kicker: "The Goal",
    goal_title: "Twenty-five lakh rupees.<br><em>One mandir. Forever.</em>",
    goal_raised: "Raised so far",
    goal_of: "of",
    goal_donors: "contributors",
    goal_donor: "contributor",
    goal_remaining: "still needed",
    goal_breakdown: "Where it goes",

    give_kicker: "Contribute",
    give_title: "Place your stone.",
    give_sub: "Choose an amount. Every contribution, of any size, is received with the same gratitude.",
    give_amount: "Amount",
    give_custom: "Other amount",
    give_name: "Name to inscribe",
    give_name_hint: "Exactly as you'd like it to appear on the Wall of Devotion.",
    give_dedication: "In honour or memory of (optional)",
    give_dedication_ph: "e.g. In loving memory of my mother",
    give_email: "Email for your receipt",
    give_phone: "Mobile number",
    give_photo: "Add a photo to your inscription (optional)",
    give_photo_btn: "Choose photo",
    give_stage: "Direct it towards",
    give_stage_any: "Wherever it is needed most",
    give_anon: "Keep my name private, show only \"A devotee\"",
    give_pay: "Contribute {amount}",
    give_secure: "Payments are processed securely by Razorpay. UPI, cards, net banking and wallets are accepted. We never see or store your card details.",
    give_min: "Please enter at least ₹11.",
    give_name_req: "Please tell us the name to inscribe.",
    give_not_ready: "Online payments are being set up. Please check back shortly, or contact us directly.",
    give_failed: "The payment did not go through. Nothing was charged. Please try again.",

    promise_kicker: "Our promise",
    promise_title: "Your name, inscribed forever.",
    promise_body: "Every person who contributes is written onto the Wall of Devotion on this website: your name, the amount you gave, and, if you wish, a photograph and a few words of dedication. It is never removed. When the mandir stands, this wall will stand with it, so that your children and theirs can find your name here.",
    promise_1_t: "Your name",
    promise_1_b: "Inscribed exactly as you write it.",
    promise_2_t: "Your offering",
    promise_2_b: "The amount recorded beside your name.",
    promise_3_t: "Your photo & words",
    promise_3_b: "Optional. A face and a dedication.",

    wall_kicker: "Wall of Devotion",
    wall_title: "The hands that are building this mandir.",
    wall_founder: "Founder · First offering",
    wall_anon: "A devotee",
    wall_you_next: "Your name belongs here.",
    wall_you_next_b: "Be part of the wall.",

    about_kicker: "The Sankalp",
    about_title: "Built under the sankalp of<br><em>Lalji Goswami.</em>",
    about_body_1: "This mandir began as a promise. Lalji Goswami took the sankalp to rebuild it properly, and made the first offering himself, five lakh rupees, so that the work could begin.",
    about_body_2: "He looks after the work at the site. This website exists so that everyone who helps can see exactly where their offering has gone.",
    about_sign: "Lalji Goswami",
    about_role: "Founder & builder",

    trust_1_t: "Every rupee recorded",
    trust_1_b: "Each contribution appears on the wall with its amount.",
    trust_2_t: "Secure payments",
    trust_2_b: "Handled end-to-end by Razorpay. Receipt sent to your email.",
    trust_3_t: "Progress shown openly",
    trust_3_b: "Each stage is updated here as the work moves forward.",

    thanks_kicker: "Dhanyavaad",
    thanks_title: "Thank you, {name}.",
    thanks_body: "Your offering of {amount} has been received. Your name is now on the Wall of Devotion, and it will stay there for as long as this mandir stands.",
    thanks_close: "See your name on the wall",

    footer_line: "Built under the sankalp of Lalji Goswami.",
    footer_contact: "Contact",
    footer_lang: "हिन्दी में देखें",
    footer_rights: "All contributions are voluntary."
  },

  hi: {
    gate_name_kicker: "स्वागत है",
    gate_name_title: "हम आपको किस नाम से पुकारें?",
    gate_name_ph: "आपका नाम",
    gate_continue: "आगे बढ़ें",
    gate_skip: "अतिथि के रूप में प्रवेश करें",
    gate_pranam: "प्रणाम",
    gate_guest: "प्रिय भक्त",
    gate_line: "पधारने के लिए धन्यवाद। आइए, आपको दिखाएँ कि क्या बन रहा है।",

    nav_journey: "यात्रा",
    nav_film: "वीडियो",
    nav_wall: "भक्ति भित्ति",
    nav_about: "संकल्प",
    nav_give: "सहयोग करें",

    hero_kicker: "प्रणाम, {name}",
    hero_title: "एक मंदिर,<br>पत्थर-दर-पत्थर,<br><em>अनेक हाथों से।</em>",
    hero_sub: "हम अपने गाँव में माँ काली का मंदिर फिर से बना रहे हैं। पुरानी दीवारें कमज़ोर हो चुकी थीं, इसलिए अगस्त में उन्हें हटाकर उसी जगह एक मज़बूत मंदिर बनाया जा रहा है। हर सहयोग और हर नाम इसका हिस्सा है।",
    hero_cta: "अपना सहयोग अर्पित करें",
    hero_more: "यात्रा देखें",
    hero_raised: "एकत्रित, लक्ष्य",
    hero_scroll: "नीचे देखें",

    intro: "मंदिर किसी एक व्यक्ति से नहीं बनता। वह उन राजमिस्त्रियों से बनता है जो हाथ से सरिया बाँधते हैं, उन पड़ोसियों से जो सिर पर रेत ढोते हैं, और उस अनजान व्यक्ति से जो यह पृष्ठ पढ़कर सहायता करने का निर्णय लेता है। यह उसी निर्माण की कहानी है, ईमानदारी से, चरण-दर-चरण।",

    journey_kicker: "यात्रा",
    journey_title: "पुरानी दीवारों से नए कलश तक।",
    journey_sub: "यहाँ की हर फ़ोटो साइट के हमारे अपने वीडियो से ली गई है।",
    stage: "चरण",
    budget: "आवश्यकता",
    when: "कब",
    status_done: "पूर्ण",
    status_now: "प्रगति पर",
    status_next: "आगामी",
    status_maa: "जय माता दी",
    stage_give: "इस चरण में सहयोग करें",
    stage_watch: "वीडियो देखें",

    stages: {
      maa: {
        title: "माँ काली",
        date: "",
        body: "यहाँ सब कुछ माँ से शुरू होता है। बरसों से माँ पुराने मंदिर से गाँव पर कृपा करती आई हैं। नया मंदिर बनने तक वे साइट के पास एक छोटे अस्थायी मंदिर में विराजमान हैं, और उनकी पूजा और श्रृंगार जारी है।",
        items: ["माँ कालिका देवी", "साइट के पास अस्थायी मंदिर", "पूजा और श्रृंगार जारी"]
      },
      brick: {
        title: "जीर्णोद्धार पूजन",
        date: "2 जुलाई 2026",
        body: "मंदिर का जीर्णोद्धार ईंटों पर रोली, चावल और फूलों से पूजन के साथ, सुबह 9 बजे के शुभ मुहूर्त में शुरू हुआ। समस्त ग्रामवासी और माँ के भक्तगण आमंत्रित थे।",
        items: ["ईंटों पर पूजन", "शुभ मुहूर्त, सुबह 9 बजे", "समस्त ग्रामवासी एवं भक्तगण आमंत्रित"]
      },
      old: {
        title: "पुराना मंदिर",
        date: "27 जून – 2 जुलाई 2026",
        body: "काम शुरू होने से पहले माँ का मंदिर ऐसा दिखता था। प्लास्टर बड़े-बड़े टुकड़ों में गिर रहा था और दीवारों में सीलन आ गई थी। हमने इसे ध्यान से रिकॉर्ड किया, ताकि इसकी याद हमेशा रहे।",
        items: ["दीवारों से गिरता प्लास्टर", "पुरानी ईंटों में सीलन", "पुराने मंदिर में माँ की मूर्ति"]
      },
      down: {
        title: "पुराना ढाँचा हटाना",
        date: "2 – 20 अगस्त 2026",
        body: "लगभग तीन हफ़्तों में छत और दीवारें तोड़ी गईं। फिर नए मंदिर की रूपरेखा खाली ज़मीन पर चूने से खींची गई।",
        items: ["छत और दीवारें तोड़ी गईं", "भूखंड से मलबा हटाया गया", "नया नक्शा चूने से चिह्नित"]
      },
      ground: {
        title: "खुदाई और सामान",
        date: "13 – 17 सितंबर 2026",
        body: "नींव के लिए गड्ढे खोदे गए। रेत को साइट पर ही छाना गया, और कंक्रीट के काम के लिए गिट्टी और ईंटों की ट्रॉलियाँ आईं।",
        items: ["नींव के गड्ढे खोदे गए", "साइट पर रेत छानी गई", "गिट्टी और ईंटें आईं"]
      },
      columns: {
        title: "सरिया और कॉलम",
        date: "18 सितंबर 2026 से",
        body: "कॉलम के लिए सरिये के पिंजरे बाँधकर गड्ढों में खड़े किए जा रहे हैं और पहली कंक्रीट ढलाई हो चुकी है। जो गोल सरिया दिख रहा है, वह नए मंदिर के आधार का आकार है।",
        items: ["कॉलम के लिए सरिया", "सीमेंट और कंक्रीट", "राजमिस्त्रियों की मज़दूरी"]
      },
      puja: {
        title: "माँ की पूजा नहीं रुकी",
        date: "29 सितंबर – 11 अक्टूबर 2026",
        body: "काम चलने तक माँ साइट के पास एक छोटे अस्थायी मंदिर में विराजमान हैं, और उनकी पूजा और श्रृंगार जारी है।",
        items: ["साइट के पास अस्थायी मंदिर", "पूजा जारी", "माँ का श्रृंगार"]
      },
      walls: {
        title: "दीवारें और छत",
        body: "कॉलम खड़े होने के बाद गर्भगृह और आगे के हिस्से की दीवारें उठाई जाएँगी और उनके ऊपर छत की ढलाई होगी।",
        items: ["ईंटें और सीमेंट", "छत की ढलाई के लिए सरिया", "शटरिंग और मज़दूरी"]
      },
      shikhar: {
        title: "शिखर",
        body: "गर्भगृह के ऊपर शिखर उठेगा, जैसा नए मंदिर के नक्शे में है: परत-दर-परत, रंगों से सजा हुआ।",
        items: ["शिखर का ढाँचा", "मचान", "सजावट और रंगाई"]
      },
      pratishtha: {
        title: "कलश एवं प्राण प्रतिष्ठा",
        body: "प्लास्टर, फ़र्श और रंगाई सबसे अंत में होगी। फिर शिखर पर कलश स्थापित होगा, माँ नए गर्भगृह में विराजमान होंगी, और प्राण प्रतिष्ठा होगी।",
        items: ["प्लास्टर, फ़र्श और रंगाई", "कलश और ध्वजा", "मूर्ति स्थापना और प्राण प्रतिष्ठा"]
      }
    },

    film_kicker: "स्थल से",
    film_title: "अपनी आँखों से देखिए।",
    film_soon: "यह वीडियो जल्द ही जोड़ा जाएगा।",

    goal_kicker: "लक्ष्य",
    goal_title: "पच्चीस लाख रुपये।<br><em>एक मंदिर। सदा के लिए।</em>",
    goal_raised: "अब तक एकत्रित",
    goal_of: "लक्ष्य",
    goal_donors: "सहयोगी",
    goal_donor: "सहयोगी",
    goal_remaining: "अभी शेष",
    goal_breakdown: "राशि का उपयोग",

    give_kicker: "सहयोग करें",
    give_title: "अपना पत्थर रखिए।",
    give_sub: "राशि चुनें। हर सहयोग, चाहे छोटा हो या बड़ा, समान कृतज्ञता से स्वीकार किया जाता है।",
    give_amount: "राशि",
    give_custom: "अन्य राशि",
    give_name: "अंकित होने वाला नाम",
    give_name_hint: "ठीक वैसा ही लिखें जैसा आप भक्ति भित्ति पर देखना चाहते हैं।",
    give_dedication: "किसी के सम्मान या स्मृति में (वैकल्पिक)",
    give_dedication_ph: "जैसे: मेरी माँ की पुण्य स्मृति में",
    give_email: "रसीद हेतु ईमेल",
    give_phone: "मोबाइल नंबर",
    give_photo: "अपने नाम के साथ फ़ोटो जोड़ें (वैकल्पिक)",
    give_photo_btn: "फ़ोटो चुनें",
    give_stage: "किस कार्य हेतु",
    give_stage_any: "जहाँ सबसे अधिक आवश्यकता हो",
    give_anon: "मेरा नाम गोपनीय रखें, केवल \"एक भक्त\" दिखाएँ",
    give_pay: "{amount} अर्पित करें",
    give_secure: "भुगतान Razorpay द्वारा सुरक्षित रूप से संसाधित होता है। UPI, कार्ड, नेट बैंकिंग और वॉलेट स्वीकार्य हैं। हम आपके कार्ड का विवरण न देखते हैं, न रखते हैं।",
    give_min: "कृपया कम से कम ₹11 दर्ज करें।",
    give_name_req: "कृपया अंकित होने वाला नाम बताएँ।",
    give_not_ready: "ऑनलाइन भुगतान की व्यवस्था की जा रही है। कृपया थोड़ी देर बाद पुनः प्रयास करें या हमसे सीधे संपर्क करें।",
    give_failed: "भुगतान पूरा नहीं हुआ। कोई राशि नहीं कटी। कृपया पुनः प्रयास करें।",

    promise_kicker: "हमारा वचन",
    promise_title: "आपका नाम, सदा के लिए अंकित।",
    promise_body: "सहयोग करने वाले हर व्यक्ति का नाम इस वेबसाइट की भक्ति भित्ति पर लिखा जाता है: आपका नाम, आपकी दी हुई राशि, और यदि आप चाहें तो एक फ़ोटो और समर्पण के कुछ शब्द। इसे कभी हटाया नहीं जाता। जब मंदिर खड़ा होगा, यह भित्ति भी उसके साथ खड़ी रहेगी, ताकि आपकी आने वाली पीढ़ियाँ यहाँ आपका नाम पा सकें।",
    promise_1_t: "आपका नाम",
    promise_1_b: "ठीक वैसा ही, जैसा आप लिखें।",
    promise_2_t: "आपकी आहुति",
    promise_2_b: "आपके नाम के साथ राशि अंकित।",
    promise_3_t: "आपकी फ़ोटो एवं शब्द",
    promise_3_b: "वैकल्पिक। एक चेहरा और एक समर्पण।",

    wall_kicker: "भक्ति भित्ति",
    wall_title: "वे हाथ जो यह मंदिर बना रहे हैं।",
    wall_founder: "संस्थापक · प्रथम आहुति",
    wall_anon: "एक भक्त",
    wall_you_next: "आपका नाम यहाँ होना चाहिए।",
    wall_you_next_b: "भित्ति का हिस्सा बनें।",

    about_kicker: "संकल्प",
    about_title: "<em>लालजी गोस्वामी</em> के<br>संकल्प से निर्मित।",
    about_body_1: "यह मंदिर एक वचन से आरंभ हुआ। लालजी गोस्वामी ने इसे ठीक से दोबारा बनाने का संकल्प लिया, और काम शुरू हो सके इसलिए पहली आहुति, पाँच लाख रुपये, स्वयं अर्पित की।",
    about_body_2: "वे साइट पर काम की देखरेख करते हैं। यह वेबसाइट इसलिए है ताकि सहयोग करने वाला हर व्यक्ति देख सके कि उसकी आहुति कहाँ लगी है।",
    about_sign: "लालजी गोस्वामी",
    about_role: "संस्थापक एवं निर्माता",

    trust_1_t: "हर रुपये का हिसाब",
    trust_1_b: "हर सहयोग राशि सहित भित्ति पर दिखता है।",
    trust_2_t: "सुरक्षित भुगतान",
    trust_2_b: "पूरी प्रक्रिया Razorpay द्वारा। रसीद आपके ईमेल पर।",
    trust_3_t: "खुली प्रगति",
    trust_3_b: "काम आगे बढ़ने पर हर चरण यहाँ अद्यतन होता है।",

    thanks_kicker: "धन्यवाद",
    thanks_title: "धन्यवाद, {name}।",
    thanks_body: "आपकी {amount} की आहुति प्राप्त हो गई है। आपका नाम अब भक्ति भित्ति पर अंकित है, और जब तक यह मंदिर खड़ा है, वहीं रहेगा।",
    thanks_close: "भित्ति पर अपना नाम देखें",

    footer_line: "लालजी गोस्वामी के संकल्प से निर्मित।",
    footer_contact: "संपर्क",
    footer_lang: "View in English",
    footer_rights: "सभी सहयोग स्वैच्छिक हैं।"
  }
};
