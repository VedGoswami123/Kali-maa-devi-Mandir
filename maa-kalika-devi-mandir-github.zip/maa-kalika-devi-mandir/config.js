/*
  Everything you are likely to change lives in this file.
  Amounts are in rupees. Photos live in assets/real, posters in assets/posters.
*/
window.MANDIR = {
  name: { en: "Maa Kalika Devi Mandir", hi: "माँ कालिका देवी मंदिर" },
  place: { en: "Near Lakshmi Narayan Mandir, Mahadevan Tola, Gurh, Rewa, Madhya Pradesh", hi: "लक्ष्मी नारायण मंदिर के पास, महादेवन टोला, गुढ़, रीवा, मध्य प्रदेश" },
  contactEmail: "goswamilalji@gmail.com",
  contactPhone: "+91 94060 42475",

  goal: 2500000, // ₹25,00,000

  // Razorpay public key (rzp_test_… or rzp_live_…). The secret never goes here; see README.
  razorpayKeyId: "",

  founder: {
    name: { en: "Lalji Goswami", hi: "लालजी गोस्वामी" },
    photo: "assets/lalji.jpg"
  },

  hero: "assets/real/old-1.jpg",

  // status: "done" | "now" | "next"
  // budget: only for work still to be paid for (these are estimates — change them to your real figures)
  // film: which of the six videos belongs to this stage
  stages: [
    { id: "maa",        image: "assets/real/maa-kali-full.jpg", status: "maa",  film: 6 },
    { id: "brick",      image: "assets/real/brick-puja.jpg", status: "done", film: 1 },
    { id: "old",        image: "assets/real/old-2.jpg",   status: "done", film: 1 },
    { id: "down",       image: "assets/real/down-1.jpg",  status: "done", film: 2 },
    { id: "ground",     image: "assets/real/sand-1.jpg",  status: "done", film: 3 },
    { id: "columns",    image: "assets/real/col-4.jpg",   status: "now",  film: 5, budget: 600000 },
    { id: "walls",      image: "assets/real/col-3.jpg",   status: "next", budget: 700000 },
    { id: "shikhar",    image: "assets/real/plan-v3.jpg", status: "next", budget: 600000 },
    { id: "pratishtha", image: "assets/real/shrine-1.jpg", status: "next", budget: 600000 }
  ],

  // The film section. Easiest: upload each video to YouTube (unlisted is fine) and paste its link into youtube: "".
  // Or put web-sized copies at assets/films/1.mp4 … 6.mp4.
  filmPoster: "assets/real/crew.jpg",
  films: [
    { poster: "assets/posters/1.jpg", src: "assets/films/1.mp4", youtube: "", len: "2:26" },
    { poster: "assets/posters/2.jpg", src: "assets/films/2.mp4", youtube: "", len: "1:49" },
    { poster: "assets/posters/3.jpg", src: "assets/films/3.mp4", youtube: "", len: "3:24" },
    { poster: "assets/posters/4.jpg", src: "assets/films/4.mp4", youtube: "", len: "5:51" },
    { poster: "assets/posters/5.jpg", src: "assets/films/5.mp4", youtube: "", len: "5:37" },
    { poster: "assets/posters/6.jpg", src: "assets/films/6.mp4", youtube: "", len: "2:38" }
  ],

  // Shown when the site is opened without the server. With the server running,
  // the list comes from data/donors.json instead.
  donors: [
    {
      name: "Lalji Goswami",
      amount: 500000,
      date: "",
      note: { en: "The first offering, so the work could begin.", hi: "पहली आहुति, ताकि काम शुरू हो सके।" },
      photo: "assets/lalji-face.jpg",
      founder: true
    }
  ]
};
