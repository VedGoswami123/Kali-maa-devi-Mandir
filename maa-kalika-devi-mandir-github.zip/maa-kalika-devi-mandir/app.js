(() => {
  "use strict";

  const M = window.MANDIR;
  const T = window.I18N;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const hasGsap = !!(window.gsap && window.ScrollTrigger);

  document.documentElement.classList.add("js");
  if (hasGsap) gsap.registerPlugin(ScrollTrigger);

  /* ---------- storage (never trusted to exist) ---------- */
  const store = {
    get(k) { try { return JSON.parse(localStorage.getItem("mandir:" + k)); } catch { return null; } },
    set(k, v) { try { localStorage.setItem("mandir:" + k, JSON.stringify(v)); } catch {} }
  };

  /* ---------- state ---------- */
  const state = {
    lang: store.get("lang") || "en",
    name: store.get("name") || "",
    donors: [],
    server: false,
    keyId: M.razorpayKeyId || "",
    amount: 5100,
    photo: null
  };

  const t = (k) => T[state.lang][k] ?? T.en[k] ?? k;
  const rupees = (n) => "₹" + Math.round(n).toLocaleString("en-IN");
  const fill = (s, o) => s.replace(/\{(\w+)\}/g, (_, k) => o[k] ?? "");
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const initials = (n) => n.trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
  const raised = () => state.donors.reduce((s, d) => s + d.amount, 0);
  // The design drawing has a white background; show it whole instead of cropping it.
  const fitClass = (src) => (src.includes("plan") ? "contain" : "");

  /* ======================================================
     RENDER
  ====================================================== */
  function render() {
    const L = state.lang;
    document.documentElement.lang = L;
    document.title = M.name[L];

    $$("[data-i18n]").forEach((el) => (el.textContent = t(el.dataset.i18n)));
    $$("[data-i18n-ph]").forEach((el) => (el.placeholder = t(el.dataset.i18nPh)));
    $$("[data-i18n-html]").forEach((el) => {
      const html = t(el.dataset.i18nHtml);
      el.innerHTML = el.classList.contains("hero__title")
        ? html.split("<br>").map((l) => `<span class="ln"><span>${l}</span></span>`).join("")
        : html;
    });
    $$("[data-mandir]").forEach((el) => (el.textContent = M[el.dataset.mandir][L]));
    $$(".lang-toggle span").forEach((s, i) => s.classList.toggle("on", (i === 0 && L === "en") || (i === 2 && L === "hi")));

    $("#hero-kicker").textContent = fill(t("hero_kicker"), { name: state.name || t("gate_guest") });
    $("#foot-email").textContent = M.contactEmail; $("#foot-email").href = "mailto:" + M.contactEmail;
    $("#foot-phone").textContent = M.contactPhone; $("#foot-phone").href = "tel:" + M.contactPhone.replace(/\s/g, "");
    $("#year").textContent = new Date().getFullYear();

    splitWords($(".js-words"));
    renderStages();
    renderFilms();
    renderGoal();
    renderAmounts();
    renderStageSelect();
    renderWall();
    renderFounder();
    updatePayLabel();
  }

  function splitWords(el) {
    el.innerHTML = el.textContent.split(/\s+/).map((w) => `<span class="w">${esc(w)}</span>`).join(" ");
  }

  const arrow = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12h15M13 6l6 6-6 6"/></svg>';
  const play = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M10 8l6 4-6 4z"/></svg>';

  function renderStages() {
    const S = T[state.lang].stages;
    const pad = (n) => String(n).padStart(2, "0");
    $("#stages").innerHTML = M.stages.map((st, i) => {
      const s = S[st.id];
      const watch = st.film ? `<a href="#" class="stage__give" data-film="${st.film}">${t("stage_watch")}${play}</a>` : "";
      const foot = st.budget
        ? `<div class="stage__budget"><span class="label">${t("budget")}</span><strong>${rupees(st.budget)}</strong></div>
           <a href="#give" class="stage__give" data-stage="${st.id}">${t("stage_give")}${arrow}</a>`
        : s.date
          ? `<div class="stage__budget"><span class="label">${t("when")}</span><strong class="date">${s.date}</strong></div>${watch}`
          : watch;
      return `
      <li class="stage" data-index="${i}">
        <div class="stage__img"><img src="${st.image}" alt="" loading="lazy" class="${fitClass(st.image)}"></div>
        <div class="stage__top">
          <span class="stage__num">${t("stage")} <b>${pad(i + 1)}</b></span>
          <span class="chip chip--${st.status}">${t("status_" + st.status)}</span>
        </div>
        <h3 class="stage__title js-reveal">${s.title}</h3>
        <p class="stage__body js-reveal">${s.body}</p>
        <ul class="stage__items js-reveal">${s.items.map((x) => `<li>${x}</li>`).join("")}</ul>
        <div class="stage__foot js-reveal">${foot}</div>
      </li>`;
    }).join("");

    const frame = $("#visual-frame");
    if (!frame.children.length) {
      frame.innerHTML = M.stages.map((st, i) =>
        `<img src="${st.image}" alt="" decoding="async" class="${[fitClass(st.image), i ? "" : "on"].join(" ").trim()}">`).join("");
    }
    $("#visual-total").textContent = pad(M.stages.length);

    $$(".stage__give[data-stage]").forEach((a) => a.addEventListener("click", () => { $("#g-stage").value = a.dataset.stage; }));
  }

  function setStage(i) {
    const imgs = $$("#visual-frame img");
    imgs.forEach((im, j) => {
      im.classList.toggle("was", im.classList.contains("on") && j !== i);
      if (j !== i) im.classList.remove("on");
    });
    imgs[i].classList.remove("was");
    imgs[i].classList.add("on");
    $("#visual-num").textContent = String(i + 1).padStart(2, "0");
    $("#visual-progress").style.width = ((i + 1) / M.stages.length) * 100 + "%";
  }

  function renderFilms() {
    const S = T[state.lang].stages;
    const dateFor = (n) => { const st = M.stages.find((x) => x.film === n); return st ? S[st.id].date : ""; };
    $("#film-row").innerHTML = M.films.map((f, i) => `
      <button class="film-card" data-film="${i + 1}">
        <img src="${f.poster}" alt="${esc(dateFor(i + 1))}" loading="lazy">
        ${f.len}
      </button>`).join("");
  }

  function renderGoal() {
    const r = raised();
    const pct = Math.min(100, (r / M.goal) * 100);
    $$(".js-goal").forEach((el) => (el.textContent = rupees(M.goal)));
    $$(".js-count-donors").forEach((el) => {
      el.textContent = state.donors.length;
      const label = el.nextElementSibling;
      if (label) label.textContent = t(state.donors.length === 1 ? "goal_donor" : "goal_donors");
    });
    $$(".js-remaining").forEach((el) => (el.textContent = rupees(Math.max(0, M.goal - r))));
    $$(".js-pct").forEach((el) => (el.textContent = Math.round(pct) + "%"));
    // Only touch numbers that have already animated in; the rest count up on first view.
    $$(".js-raised").forEach((el) => { if (el.dataset.done) el.textContent = rupees(r); });
    $$(".js-bar").forEach((el) => { if (el.dataset.done) el.style.width = pct + "%"; });

    const S = T[state.lang].stages;
    const funded = M.stages.filter((st) => st.budget);
    $("#breakdown-bar").innerHTML = funded.map((st) =>
      `<span class="${st.status}" style="flex:${st.budget}" title="${esc(S[st.id].title)}"></span>`).join("");
    $("#breakdown-legend").innerHTML = funded.map((st) =>
      `<li class="${st.status}"><span>${S[st.id].title}</span><b>${rupees(st.budget)}</b></li>`).join("");
  }

  function fillBars(el) {
    const pct = Math.min(100, (raised() / M.goal) * 100);
    el.dataset.done = 1;
    if (hasGsap && !reduced) gsap.fromTo(el, { width: 0 }, { width: pct + "%", duration: 2.4, ease: "expo.out" });
    else el.style.width = pct + "%";
  }

  function countUp(el) {
    const end = raised();
    el.dataset.done = 1;
    if (!hasGsap || reduced) { el.textContent = rupees(end); return; }
    const o = { v: 0 };
    gsap.to(o, { v: end, duration: 2.4, ease: "expo.out", onUpdate: () => (el.textContent = rupees(o.v)) });
  }

  const PRESETS = [1100, 2100, 5100, 11000, 21000, 51000];
  function renderAmounts() {
    $("#amounts").innerHTML = PRESETS.map((a) =>
      `<button type="button" class="amount ${a === state.amount && !$("#amount-custom").value ? "on" : ""}" data-amt="${a}">${rupees(a)}</button>`).join("");
    $$(".amount").forEach((b) => b.addEventListener("click", () => {
      state.amount = +b.dataset.amt;
      $("#amount-custom").value = "";
      $$(".amount").forEach((x) => x.classList.toggle("on", x === b));
      updatePayLabel();
    }));
  }

  function renderStageSelect() {
    const sel = $("#g-stage"), cur = sel.value;
    const S = T[state.lang].stages;
    sel.innerHTML = `<option value="">${t("give_stage_any")}</option>` +
      M.stages.filter((s) => s.budget).map((s) => `<option value="${s.id}">${S[s.id].title}</option>`).join("");
    sel.value = cur;
  }

  function updatePayLabel() {
    $("#pay-label").textContent = fill(t("give_pay"), { amount: rupees(state.amount || 0) });
  }

  function donorCard(d) {
    const name = d.anonymous ? t("wall_anon") : d.name;
    const note = typeof d.note === "object" ? d.note?.[state.lang] || d.note?.en : d.note;
    const date = d.date ? new Date(d.date).toLocaleDateString(state.lang === "hi" ? "hi-IN" : "en-IN", { day: "numeric", month: "long", year: "numeric" }) : "";
    const mono = esc(d.anonymous ? "ॐ" : initials(name));
    const avatar = d.photo && !d.anonymous
      ? `<img src="${esc(d.photo)}" alt="" loading="lazy" onerror="this.nextElementSibling.hidden=false;this.remove()"><span hidden>${mono}</span>`
      : mono;
    return `
      <li class="${d.founder ? "is-founder" : ""}"><div class="donor ${d.founder ? "donor--founder" : ""} ${d.fresh ? "donor--new" : ""}">
        <div class="donor__top">
          <span class="avatar">${avatar}</span>
          <div>
            <p class="donor__name">${esc(name)}</p>
            ${date ? `<span class="donor__date">${esc(date)}</span>` : ""}
          </div>
        </div>
        <p class="donor__note">${esc(note || "")}</p>
        <div class="donor__amt">
          <b>${rupees(d.amount)}</b>
          ${d.founder ? `<span class="donor__tag">${t("wall_founder")}</span>` : ""}
        </div>
      </div></li>`;
  }

  function renderWall() {
    const list = [...state.donors].sort((a, b) => (b.founder ? 1 : 0) - (a.founder ? 1 : 0) || new Date(b.date) - new Date(a.date));
    $("#wall-grid").innerHTML = list.map(donorCard).join("") + `
      <li><a href="#give" class="donor donor--next">
        <p class="donor__name">${t("wall_you_next")}</p>
        <span>${t("wall_you_next_b")} →</span>
      </a></li>`;
  }

  function renderFounder() {
    const p = $("#founder-portrait");
    if (p.querySelector("img")) return;
    const img = new Image();
    img.alt = M.founder.name.en;
    img.onload = () => { p.appendChild(img); p.querySelector(".portrait__mono")?.remove(); };
    img.src = M.founder.photo;
  }

  /* ======================================================
     DATA
  ====================================================== */
  async function loadDonors() {
    try {
      const res = await fetch("/api/donors", { cache: "no-store" });
      if (!res.ok) throw 0;
      const data = await res.json();
      state.donors = data.donors;
      state.server = true;
      if (data.keyId) state.keyId = data.keyId;
    } catch {
      state.donors = [...M.donors, ...(store.get("local-donors") || [])];
    }
  }

  /* ======================================================
     GATE
  ====================================================== */
  function gateStep(name) {
    $$(".gate__step").forEach((s) => s.classList.toggle("is-active", s.dataset.step === name));
  }

  function initGate() {
    $$(".lang-btn").forEach((b) => b.addEventListener("click", () => {
      state.lang = b.dataset.lang;
      store.set("lang", state.lang);
      render();
      $("#visitor-name").value = state.name;
      gateStep("name");
      setTimeout(() => $("#visitor-name").focus({ preventScroll: true }), 700);
    }));
    $("#name-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const v = $("#visitor-name").value.trim();
      if (!v) { $("#visitor-name").focus(); return; }
      enter(v);
    });
    $("#gate-skip").addEventListener("click", () => enter(""));
  }

  function enter(name) {
    state.name = name;
    store.set("name", name);
    $("#hello-name").textContent = (name || t("gate_guest")) + (state.lang === "hi" ? "।" : ".");
    if (name) $("#g-name").value = name;
    render();
    gateStep("hello");

    const lift = () => {
      const gate = $("#gate");
      document.body.classList.remove("is-locked");
      window.scrollTo(0, 0);
      if (hasGsap && !reduced) {
        const tl = gsap.timeline({ onComplete: () => gate.classList.add("is-gone") });
        tl.to(".gate__step.is-active", { opacity: 0, y: -24, duration: .7, ease: "power2.in" })
          .to(gate, { clipPath: "inset(0 0 100% 0)", duration: 1.3, ease: "expo.inOut" }, "-=.15")
          .add(heroIntro, "-=.75");
      } else {
        gate.classList.add("is-gone");
        heroIntro();
      }
      startSite();
    };
    setTimeout(lift, reduced ? 600 : 2300);
  }

  /* ======================================================
     MOTION
  ====================================================== */
  let lenis;
  function startSite() {
    if (window.Lenis && !reduced) {
      lenis = new Lenis({ duration: 1.25, easing: (x) => Math.min(1, 1.001 - Math.pow(2, -10 * x)), smoothWheel: true });
      if (hasGsap) {
        lenis.on("scroll", ScrollTrigger.update);
        gsap.ticker.add((time) => lenis.raf(time * 1000));
        gsap.ticker.lagSmoothing(0);
      } else {
        const raf = (time) => { lenis.raf(time); requestAnimationFrame(raf); };
        requestAnimationFrame(raf);
      }
    }
    document.addEventListener("click", (e) => {
      const a = e.target.closest('a[href^="#"]');
      if (!a || a.dataset.film) return;
      const id = a.getAttribute("href");
      if (id.length < 2) return;
      const el = $(id);
      if (!el) return;
      e.preventDefault();
      if (lenis) lenis.scrollTo(el, { offset: id === "#give" ? -20 : -70, duration: 1.8 });
      else el.scrollIntoView({ behavior: reduced ? "auto" : "smooth" });
    });
    initHeader();
    initMotion();
  }

  function heroIntro() {
    if (!hasGsap || reduced) {
      $$(".hero .js-raised").forEach(countUp); $$(".hero .js-bar").forEach(fillBars);
      return;
    }
    gsap.fromTo(".hero__img", { scale: 1.18 }, { scale: 1, duration: 3.2, ease: "expo.out" });
    gsap.from(".hero__title .ln > span", { yPercent: 110, duration: 1.5, ease: "expo.out", stagger: .09, delay: .1 });
    gsap.from([".hero__kicker", ".hero__sub", ".hero__ctas", ".hero__goal"], { opacity: 0, y: 24, duration: 1.4, ease: "expo.out", stagger: .1, delay: .45 });
    setTimeout(() => { $$(".hero .js-raised").forEach(countUp); $$(".hero .js-bar").forEach(fillBars); }, 900);
  }

  function initHeader() {
    const head = $("#site-head");
    let last = 0;
    const onScroll = () => {
      const y = window.scrollY;
      head.classList.toggle("is-solid", y > window.innerHeight * .8);
      head.classList.toggle("is-hidden", y > last && y > window.innerHeight);
      last = y;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
  }

  function initMotion() {
    const io = new IntersectionObserver((es) => es.forEach((e) => {
      if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); }
    }), { rootMargin: "0px 0px -8% 0px" });
    $$(".js-reveal:not(.in)").forEach((el) => io.observe(el));

    const goalIo = new IntersectionObserver((es) => es.forEach((e) => {
      if (!e.isIntersecting) return;
      goalIo.unobserve(e.target);
      $$(".goal .js-raised").forEach(countUp);
      $$(".goal .js-bar").forEach(fillBars);
      $(".breakdown").classList.add("in");
    }), { threshold: .35 });
    goalIo.observe($(".goal__panel"));

    if (!hasGsap || reduced) {
      $$(".statement__text .w").forEach((w) => w.classList.add("on"));
      return;
    }

    gsap.to(".hero__img", { yPercent: 12, ease: "none", scrollTrigger: { trigger: ".hero", start: "top top", end: "bottom top", scrub: true } });
    gsap.to(".hero__inner", { y: -80, opacity: .2, ease: "none", scrollTrigger: { trigger: ".hero", start: "40% top", end: "bottom top", scrub: true } });

    bindWords();
    bindStages();

    gsap.to(".film__clip", { clipPath: "inset(0% 0% 0% 0% round 6px)", ease: "none", scrollTrigger: { trigger: ".film__frame", start: "top 90%", end: "center 55%", scrub: true } });
    gsap.to(".film__clip img", { scale: 1, ease: "none", scrollTrigger: { trigger: ".film__frame", start: "top bottom", end: "bottom top", scrub: true } });

    gsap.fromTo(".portrait", { y: 40 }, { y: -40, ease: "none", scrollTrigger: { trigger: ".about", start: "top bottom", end: "bottom top", scrub: true } });
  }

  let wordST, stageSTs = [];
  function bindWords() {
    if (!hasGsap || reduced) { $$(".statement__text .w").forEach((w) => w.classList.add("on")); return; }
    wordST?.kill();
    const words = $$(".statement__text .w");
    wordST = ScrollTrigger.create({
      trigger: ".statement", start: "top 75%", end: "bottom 55%", scrub: true,
      onUpdate: (self) => {
        const n = Math.round(self.progress * words.length);
        words.forEach((w, i) => w.classList.toggle("on", i < n));
      }
    });
  }

  function bindStages() {
    stageSTs.forEach((s) => s.kill());
    if (!hasGsap) return;
    // The active stage is the last one whose top has crossed the middle of the screen.
    let cur = -1;
    const stages = $$(".stage");
    const pick = () => {
      const mid = innerHeight * .55;
      let i = 0;
      stages.forEach((el, j) => { if (el.getBoundingClientRect().top < mid) i = j; });
      if (i !== cur) { cur = i; setStage(i); }
    };
    stageSTs = [ScrollTrigger.create({ trigger: "#stages", start: "top bottom", end: "bottom top", onUpdate: pick, onRefresh: pick })];
  }

  /* ======================================================
     VIDEO PLAYER
  ====================================================== */
  function initPlayer() {
    const player = $("#player"), video = $("#player-video"), frame = $("#player-frame"), soon = $("#player-soon");
    document.addEventListener("click", (e) => {
      const b = e.target.closest("[data-film]");
      if (!b) return;
      e.preventDefault();
      const f = M.films[+b.dataset.film - 1];
      const yt = /(?:youtu\.be\/|v=|shorts\/|embed\/)([\w-]{11})/.exec(f.youtube || "");
      soon.hidden = true; video.hidden = !!yt; frame.hidden = !yt;
      if (yt) {
        frame.src = `https://www.youtube-nocookie.com/embed/${yt[1]}?autoplay=1&rel=0`;
      } else {
        video.poster = f.poster;
        video.src = f.src;
        video.onerror = () => { video.hidden = true; soon.hidden = false; };
        video.play().catch(() => {});
      }
      player.hidden = false;
      lenis?.stop();
    });
    const close = () => { video.pause(); video.removeAttribute("src"); video.load(); frame.src = "about:blank"; player.hidden = true; lenis?.start(); };
    $("#player-close").addEventListener("click", close);
    player.addEventListener("click", (e) => { if (e.target === player) close(); });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !player.hidden) close(); });
  }

  /* ======================================================
     LANGUAGE SWITCH (after entry)
  ====================================================== */
  function switchLang() {
    state.lang = state.lang === "en" ? "hi" : "en";
    store.set("lang", state.lang);
    render();
    $$(".js-reveal").forEach((el) => el.classList.add("in"));
    bindWords();
    bindStages();
    if (hasGsap) ScrollTrigger.refresh();
  }

  /* ======================================================
     GIVING
  ====================================================== */
  function toast(msg) {
    const el = $("#toast");
    el.textContent = msg;
    el.classList.add("on");
    clearTimeout(toast.t);
    toast.t = setTimeout(() => el.classList.remove("on"), 5200);
  }

  function shrinkPhoto(file) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const s = 320, c = document.createElement("canvas");
        const r = Math.max(s / img.width, s / img.height);
        c.width = c.height = s;
        c.getContext("2d").drawImage(img, (s - img.width * r) / 2, (s - img.height * r) / 2, img.width * r, img.height * r);
        resolve(c.toDataURL("image/jpeg", .82));
        URL.revokeObjectURL(img.src);
      };
      img.onerror = () => resolve(null);
      img.src = URL.createObjectURL(file);
    });
  }

  function initGive() {
    $("#amount-custom").addEventListener("input", (e) => {
      const n = parseInt(e.target.value.replace(/\D/g, ""), 10) || 0;
      e.target.value = n ? n.toLocaleString("en-IN") : "";
      state.amount = n;
      $$(".amount").forEach((x) => x.classList.toggle("on", !n && +x.dataset.amt === state.amount));
      updatePayLabel();
    });

    $("#g-photo").addEventListener("change", async (e) => {
      const f = e.target.files[0];
      if (!f) return;
      state.photo = await shrinkPhoto(f);
      $("#photo-thumb").style.backgroundImage = state.photo ? `url(${state.photo})` : "";
    });

    $("#give-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      const err = $("#form-error");
      err.textContent = "";
      const donor = {
        name: $("#g-name").value.trim(),
        amount: state.amount,
        note: $("#g-ded").value.trim(),
        email: $("#g-email").value.trim(),
        phone: $("#g-phone").value.trim(),
        stage: $("#g-stage").value,
        anonymous: $("#g-anon").checked,
        photo: state.photo
      };
      if (!donor.amount || donor.amount < 11) { err.textContent = t("give_min"); return; }
      if (!donor.name) { err.textContent = t("give_name_req"); $("#g-name").focus(); return; }
      if (!window.Razorpay || !state.keyId) { toast(t("give_not_ready")); return; }

      const btn = $("#pay-btn");
      btn.disabled = true;
      try {
        let order = null;
        if (state.server) {
          const r = await fetch("/api/order", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ amount: donor.amount }) });
          if (r.ok) order = await r.json();
        }
        openCheckout(donor, order);
      } catch {
        toast(t("give_failed"));
      } finally {
        btn.disabled = false;
      }
    });
  }

  function openCheckout(donor, order) {
    const rzp = new Razorpay({
      key: state.keyId,
      amount: donor.amount * 100,
      currency: "INR",
      order_id: order?.id,
      name: M.name[state.lang],
      description: state.lang === "hi" ? "मंदिर निर्माण हेतु सहयोग" : "Contribution to the mandir",
      prefill: { name: donor.name, email: donor.email, contact: donor.phone },
      notes: { inscription: donor.anonymous ? "Anonymous" : donor.name, dedication: donor.note.slice(0, 250), stage: donor.stage || "general" },
      theme: { color: "#8C2B1D" },
      handler: (resp) => onPaid(donor, resp)
    });
    rzp.on("payment.failed", () => toast(t("give_failed")));
    rzp.open();
  }

  async function onPaid(donor, resp) {
    const entry = {
      name: donor.name, amount: donor.amount, note: donor.note, anonymous: donor.anonymous,
      stage: donor.stage, photo: donor.photo, date: new Date().toISOString(), paymentId: resp.razorpay_payment_id
    };
    let saved = entry;
    if (state.server) {
      try {
        const r = await fetch("/api/verify", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...resp, donor: { ...entry, email: donor.email, phone: donor.phone } })
        });
        if (r.ok) saved = (await r.json()).donor;
      } catch {}
    } else {
      const local = store.get("local-donors") || [];
      local.push(entry);
      store.set("local-donors", local);
    }
    saved.fresh = true;
    state.donors.push(saved);
    $$(".js-raised, .js-bar").forEach((el) => (el.dataset.done = 1));
    renderGoal();
    renderWall();
    showThanks(donor);
  }

  function showThanks(donor) {
    $("#thanks-title").textContent = fill(t("thanks_title"), { name: donor.anonymous ? t("gate_guest") : donor.name });
    $("#thanks-body").textContent = fill(t("thanks_body"), { amount: rupees(donor.amount) });
    $("#thanks").hidden = false;
    lenis?.stop();
    if (hasGsap && !reduced) gsap.from(".thanks__card", { y: 40, opacity: 0, duration: 1.2, ease: "expo.out" });
  }

  $("#thanks-close").addEventListener("click", () => {
    $("#thanks").hidden = true;
    lenis?.start();
    lenis ? lenis.scrollTo("#wall", { offset: -70, duration: 1.8 }) : $("#wall").scrollIntoView({ behavior: "smooth" });
  });

  /* ======================================================
     BOOT
  ====================================================== */
  $("#lang-toggle").addEventListener("click", switchLang);
  $("#foot-lang").addEventListener("click", switchLang);

  (async () => {
    await loadDonors();
    render();
    initGate();
    initGive();
    initPlayer();
  })();
})();
