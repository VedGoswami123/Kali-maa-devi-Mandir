// POST /api/order { amount } — creates a Razorpay order for the amount in rupees.
const { KEY_ID, KEY_SECRET, rzp } = require("./_lib/store");

module.exports = async (req, res) => {
  if (req.method !== "POST") return res.status(405).json({ error: "method not allowed" });
  if (!KEY_ID || !KEY_SECRET) return res.status(503).json({ error: "payments not configured" });
  const rupees = Math.floor(Number((req.body || {}).amount));
  if (!(rupees >= 11 && rupees <= 10000000)) return res.status(400).json({ error: "invalid amount" });
  try {
    const order = await rzp("POST", "/orders", { amount: rupees * 100, currency: "INR", receipt: "m_" + Date.now() });
    res.status(200).json({ id: order.id });
  } catch (e) {
    console.error(e);
    res.status(502).json({ error: "could not create order" });
  }
};
