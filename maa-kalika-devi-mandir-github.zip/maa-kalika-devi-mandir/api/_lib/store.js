// Shared helpers for the API functions. Files under api/_lib are not deployed as endpoints.
//
// Donors are kept in Upstash Redis (add it from the Vercel dashboard: Storage → Upstash for Redis).
// Vercel sets KV_REST_API_URL / KV_REST_API_TOKEN (or UPSTASH_REDIS_REST_URL / _TOKEN) automatically.

const REDIS_URL = process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL || "";
const REDIS_TOKEN = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN || "";
const KEY_ID = process.env.RAZORPAY_KEY_ID || "";
const KEY_SECRET = process.env.RAZORPAY_KEY_SECRET || "";

// The founder's offering is always first on the wall.
const FOUNDER = {
  id: "founder",
  name: "Lalji Goswami",
  amount: 500000,
  date: "",
  note: { en: "The first offering, so the work could begin.", hi: "पहली आहुति, ताकि काम शुरू हो सके।" },
  photo: "assets/lalji-face.jpg",
  founder: true
};

const hasStore = () => !!(REDIS_URL && REDIS_TOKEN);

async function redis(...command) {
  const r = await fetch(REDIS_URL, {
    method: "POST",
    headers: { Authorization: "Bearer " + REDIS_TOKEN, "Content-Type": "application/json" },
    body: JSON.stringify(command)
  });
  const data = await r.json();
  if (!r.ok || data.error) throw new Error(data.error || "redis " + r.status);
  return data.result;
}

async function readDonors() {
  const rows = await redis("LRANGE", "donors", "0", "-1");
  return [FOUNDER, ...rows.map((s) => JSON.parse(s))];
}

async function addDonor(donor) {
  await redis("RPUSH", "donors", JSON.stringify(donor));
}

// Returns false if this payment was already recorded.
async function claimPayment(paymentId) {
  return (await redis("SET", "paid:" + paymentId, "1", "NX")) === "OK";
}

async function findDonor(paymentId) {
  return (await readDonors()).find((d) => d.paymentId === paymentId) || null;
}

// Email and phone are kept for receipts but never sent to the browser.
const publicDonor = ({ email, phone, ...d }) => d;

const rzp = (method, url, body) => fetch("https://api.razorpay.com/v1" + url, {
  method,
  headers: { Authorization: "Basic " + Buffer.from(KEY_ID + ":" + KEY_SECRET).toString("base64"), "Content-Type": "application/json" },
  body: body && JSON.stringify(body)
}).then(async (r) => { if (!r.ok) throw new Error(await r.text()); return r.json(); });

const clean = (s, n) => String(s || "").replace(/[\u0000-\u001f]/g, "").trim().slice(0, n);

module.exports = { KEY_ID, KEY_SECRET, hasStore, readDonors, addDonor, claimPayment, findDonor, publicDonor, rzp, clean };
