// POST /api/verify — checks Razorpay's signature, confirms the payment with Razorpay,
// and adds the donor to the Wall of Devotion.
const crypto = require("crypto");
const { KEY_SECRET, hasStore, addDonor, claimPayment, findDonor, publicDonor, rzp, clean } = require("./_lib/store");

module.exports = async (req, res) => {
  if (req.method !== "POST") return res.status(405).json({ error: "method not allowed" });
  if (!KEY_SECRET || !hasStore()) return res.status(503).json({ error: "not configured" });

  const b = req.body || {};
  const expected = crypto.createHmac("sha256", KEY_SECRET).update(b.razorpay_order_id + "|" + b.razorpay_payment_id).digest("hex");
  const sig = String(b.razorpay_signature || "");
  if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) {
    return res.status(400).json({ error: "signature mismatch" });
  }

  try {
    // The amount comes from Razorpay, never from the browser.
    const payment = await rzp("GET", "/payments/" + encodeURIComponent(b.razorpay_payment_id));
    if (!["captured", "authorized"].includes(payment.status)) return res.status(400).json({ error: "payment not completed" });

    // A payment is only ever recorded once, even if the browser retries.
    if (!(await claimPayment(payment.id))) {
      const existing = await findDonor(payment.id);
      return res.status(200).json({ donor: existing && publicDonor(existing) });
    }

    const d = b.donor || {};
    // Photos arrive already shrunk to 320px by the page; anything else is ignored.
    const photo = /^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(d.photo || "") && d.photo.length < 200000 ? d.photo : null;

    const donor = {
      id: crypto.randomBytes(6).toString("hex"),
      name: clean(d.name, 60) || "A devotee",
      amount: payment.amount / 100,
      note: clean(d.note, 90),
      anonymous: !!d.anonymous,
      stage: clean(d.stage, 20),
      photo,
      date: new Date().toISOString(),
      paymentId: payment.id,
      email: clean(d.email, 120),
      phone: clean(d.phone, 20)
    };
    await addDonor(donor);
    res.status(200).json({ donor: publicDonor(donor) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "could not record donation" });
  }
};
