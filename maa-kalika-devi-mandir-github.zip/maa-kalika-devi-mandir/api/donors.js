// GET /api/donors — the Wall of Devotion, plus the public Razorpay key.
const { KEY_ID, hasStore, readDonors, publicDonor } = require("./_lib/store");

module.exports = async (req, res) => {
  if (req.method !== "GET") return res.status(405).json({ error: "method not allowed" });
  // Without a database the page falls back to the list in config.js.
  if (!hasStore()) return res.status(503).json({ error: "storage not configured" });
  try {
    const donors = await readDonors();
    res.setHeader("Cache-Control", "no-store");
    res.status(200).json({ keyId: KEY_ID, donors: donors.map(publicDonor) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "could not load donors" });
  }
};
